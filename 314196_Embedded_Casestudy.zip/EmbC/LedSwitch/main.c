/*
 */

#include <avr/io.h>
#include<util/delay.h>

int main(void)
{

    DDRB|=(1<<PB0);    //set B0=1 for led

    DDRD&=~(1<<PD0);   // clear bit
    PORTD|=(1<<PD0);

   while(1)
    {
        if(!(PIND&(1<<PD0)))  //SWITCH PRESS
        {
            PORTB|=(1<<PB0);
            _delay_ms(20);
        }
        else
        {
            PORTB&=~(1<<PB0);
            _delay_ms(2000);
        }
    }

    return 0;
}
