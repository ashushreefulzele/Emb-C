#ifndef ACTIVITY_2_H_INCLUDED
#define ACTIVITY_2_H_INCLUDED

void ();

#endif
