/*
 */

#include <avr/io.h>
#include <util/delay.h>
#include<avr/interrupt.h>

unsigned volatile overflow;

void InitADC()
{
    ADMUX = (1<<REFS0);
    ADCSRA = (1<<ADEN)|(7<<ADPS0);
}

uint16_t ReadADC(uint8_t ch)
{
    ADMUX&=0xf8;
    ch=ch&0b00000111;
    ADMUX|=ch;

    ADCSRA|=(1<<ADSC);

    while(!(ADCSRA & (1<<ADIF)));

    ADCSRA|=(1<<ADIF);
    return(ADC);
}
int main(void)
{
PORTD|=(1<<PB0);//LED
TCCR0B|=(1<<CS02);
TIMSK0|=(1<<TOIE0);
TCNT0=0;
overflow=0;
sei();




    InitADC();
    uint16_t temp;


    while(1)
    {
       if(overflow>12)
       {

           if(TCNT0>=52)
           {

               PORTD^=(1<<PD6);
               TCNT0=0;
               overflow=0;
           }


        temp= ReadADC(0);
        _delay_ms(200);
    }

    }
    return 0;
}
