#ifndef UART_H_INCLUDED
#define UART_H_INCLUDED

void USARTInit(uint16_t );
char USARTReadChar();
void USARTWriteChar(char );


#endif // UART_H_INCLUDED
