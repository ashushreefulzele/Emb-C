/*
 */

#include <avr/io.h>
#include<util/delay.h>

int main(void)
{

    DDRB|=(1<<PB0); //set B0=1 for led
    DDRB|=(1<<PB1);//set B1=1 FOR LED

    DDRD&=~(1<<PD0); //clear bit
    PORTD|=(1<<PD0); //set bit

    DDRB&=~(1<<PD1);
    PORTD|=(1<<PD1);

    while(1)
    {
        if(!(PIND&((1<<PD0)|(1<<PD1)))) //switch press

        {
            PORTB|=(1<<PB0)|(1<<PB1);
            _delay_ms(20);
        }
        else
            {
               PORTB|=~(1<<PB0)|(1<<PB1);
               _delay_ms(2000);
            }

    }

    return 0;


}
